## Emoji test.

1. Pick up some emoji and insert it using the dialog window.
